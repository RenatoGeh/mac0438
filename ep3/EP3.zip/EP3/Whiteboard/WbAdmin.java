// WbAdmin.java 
//
// MAC-438 Programacao Concorrente
// USP - Instituto de Matematica e Estatistica
//
// Prof. Marcel P. Jackowski
// mjack@ime.usp.br
//

package Whiteboard;

import java.io.*;
import java.util.*;

public class WbAdmin
{
    private Vector<WbServer> vServers;

    private static final String menu = 
	"\nWbAdmin: cria [s]ervidor, [a]diciona cliente, " +
	"emite [r]elatorio, [t]ransfere lousa, para sair pressione [x]";

    public WbAdmin() {
    }

    private void serverCreate() {
		String args = Invoke.promptAndGet("NomeMaquinaServidor");
		Invoke.javaVM('S',  args); // S for Server
    }

    private void addClientReq() {
		String args = Invoke.promptAndGet("NomeBoard Display ServidorURL");
		Invoke.javaVM('C', args); // C for Client
    }

    private void transferReq() {
    	//
		// PARA VOCE FAZER: Transferir uma lousa para um novo servidor.
		//
    }

    private void queryReq() {    
    	// 
		// PARA VOCE FAZER: Emitir relatorio de todos os servidores.
		//
    }

    private void userInteract() {
		while (true) {
		    String choice = Invoke.promptAndGet(menu);
		    switch (choice.charAt(0)) {
		    case 's': serverCreate(); break;
		    case 'a': addClientReq(); break;
		    case 'r': queryReq(); break;
		    case 't': transferReq(); break;
		    case 'x': System.exit(0); break;
		    }
		}
    }
	
    public static void main(String[] args) {
		WbAdmin wa = new WbAdmin();
		wa.userInteract();
    }
}

// -eof-
