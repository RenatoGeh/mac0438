killall rmiregistry java

 rmiregistry 1099 &
 java Whiteboard.WbServerImpl 1 localhost &
 java Whiteboard.WbClientImpl 22 b0 localhost rmi://localhost:1099/S1 &
 java Whiteboard.WbClientImpl 4  b0 localhost rmi://localhost:1099/S1 &
 java Whiteboard.WbClientImpl 7 b2 localhost rmi://localhost:1099/S1 &
 java Whiteboard.WbClientImpl 65 b2 localhost rmi://localhost:1099/S1 &
